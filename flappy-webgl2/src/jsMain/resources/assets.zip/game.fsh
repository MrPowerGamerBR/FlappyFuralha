#version 300 es // Required to be set to es
precision highp float; // Required for es

in vec2 vUV;
out vec4 fragColor;

uniform sampler2D uTexture;

void main() {
    fragColor = texture(uTexture, vUV);
}